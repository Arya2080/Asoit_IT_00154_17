<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cal.c</title>
</head>
<body>
    <form method="post">
        Enter The First Numaber:
        <input type="number" name="number1" /><br><br>
        Enter The Second Numaber:
        <input type="number" name="number2" /><br><br>
        <input type="submit" name="submit" value="Add">
        <input type="push" name="push" value="sub">
        <input type="submit" name="submit" value="mul">
        <input type="submit" name="submit" value="div">
    
    </form>
    <?php
    if(isset($_POST['submit']))
    {
        $number1 = $_POST['number1'];
        $number2 = $_POST['number2'];
        $sum = $number1+$number2;
        echo "the sum is".$sum;
        $sub = $number1-$number2;
        echo "the sub is".$sum;
        $mul = $number1*$number2;
        echo "the mul$mul is".$sum;
        $div = $number1/$number2;
        echo "the div is".$sum;
        
        
    }
//     echo "<br>";
//     if(isset($_POST['submit']))
//     {
//         $number1 = $_POST['number1'];
//         $number2 = $_POST['number2'];
//         $sum = $number1-$number2;
//         echo "the sub is".$sum;
        
//     }
//     echo "<br>";
//    if(isset($_POST['submit']))
//     {
//         $number1 = $_POST['number1'];
//         $number2 = $_POST['number2'];
//         $sum = $number1*$number2;
//         echo "the mul is".$sum;
        
//     }
//     echo "<br>";
    
//    if(isset($_POST['submit']))
//     {
//         $number1 = $_POST['number1'];
//         $number2 = $_POST['number2'];
//         $sum = $number1/$number2;
//         echo "the div is".$sum;
        
//     }
   
    ?>

</body>
</html>